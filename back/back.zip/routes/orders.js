const router = require("express").Router()
const { orderValidation } = require("../validation")
// const bcrypt = require("bcryptjs")

//VALIDATION

router.get("/", async (req, res) => {
  const orders = []
})

module.exports = router
